const { chromium } = require('playwright');
(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  for (const f of process.argv.slice(2)){
    const p=await b.newPage({viewport:{width:1600,height:1000}});
    await p.goto('file://'+process.cwd()+'/'+f);
    await p.waitForTimeout(8000);
    await p.evaluate(()=>{ window.__ft=[]; let l=performance.now();
      (function loop(){ const n=performance.now(); window.__ft.push(n-l); l=n; requestAnimationFrame(loop) })(); });
    await p.mouse.move(1592,992); await p.mouse.down();
    await p.mouse.move(600,400,{steps:30}); await p.mouse.up();
    await p.waitForTimeout(2500);
    const r=await p.evaluate(()=>{ const a=window.__ft.slice(5).sort((x,y)=>x-y);
      const q=t=>a[Math.floor(a.length*t)].toFixed(1);
      return {frames:a.length, median:q(.5), p90:q(.9), p99:q(.99), worst:a[a.length-1].toFixed(1),
              over32:a.filter(v=>v>32).length}; });
    console.log(f.padEnd(34), JSON.stringify(r));
    await p.close();
  }
  await b.close();
})();
