const { chromium } = require('playwright');
const findPic=async p=>p.evaluate(()=>{
  for(let y=200;y<820;y+=20) for(let x=250;x<1350;x+=20){
    const n=hitAt(x,y);
    if(n && n.el.getBoundingClientRect().width>240) return {x,y};
  } return null;});
(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const p=await b.newPage({viewport:{width:1600,height:1000}});
  const errs=[]; p.on('pageerror',e=>errs.push(String(e)));
  await p.goto('file://'+process.cwd()+'/build4/peel-v2.html');
  await p.waitForTimeout(9000);
  let pt=await findPic(p);
  await p.mouse.move(pt.x,pt.y); await p.waitForTimeout(800);
  await p.screenshot({path:'shots/f-hover.png'});
  const hot=await p.evaluate(()=>document.querySelectorAll('.ph.hot').length);
  await p.mouse.click(pt.x,pt.y); await p.waitForTimeout(1300);
  await p.screenshot({path:'shots/f-card.png'});
  const opened=await p.evaluate(()=>document.getElementById('ovl').classList.contains('on'));
  // Esc closes
  await p.keyboard.press('Escape'); await p.waitForTimeout(900);
  const closed=await p.evaluate(()=>!document.getElementById('ovl').classList.contains('on'));
  // open again, close by clicking the backdrop
  pt=await findPic(p); await p.mouse.move(pt.x,pt.y); await p.waitForTimeout(400);
  await p.mouse.click(pt.x,pt.y); await p.waitForTimeout(1000);
  await p.mouse.click(40,40); await p.waitForTimeout(900);
  const closed2=await p.evaluate(()=>!document.getElementById('ovl').classList.contains('on'));
  // peel still works from the corner
  await p.mouse.move(1592,992); await p.mouse.down();
  await p.mouse.move(700,450,{steps:20}); await p.mouse.up(); await p.waitForTimeout(2600);
  await p.screenshot({path:'shots/f-peel.png'});
  const peeled=await p.evaluate(()=>getComputedStyle(document.getElementById('world')).visibility);
  // and click-to-open the corner
  await p.mouse.click(200,200); await p.waitForTimeout(2400);
  await p.mouse.click(1560,960); await p.waitForTimeout(2400);
  await p.screenshot({path:'shots/f-cornerclick.png'});
  console.log({hot,opened,escClosed:closed,backdropClosed:closed2,peeled,errs:errs.slice(0,2)});
  await b.close();
})();
