const { chromium } = require('playwright');
/* Does the wheel keep the same real-world speed when frames get expensive? */
const MEASURE = load => `(async()=>{
  if(${load}){ (function burn(){ const t=performance.now(); while(performance.now()-t<22){} requestAnimationFrame(burn) })(); }
  await new Promise(r=>setTimeout(r,600));
  const r0=HERO.rot, t0=performance.now(); let f=0;
  const c=()=>{f++;requestAnimationFrame(c)}; c();
  await new Promise(r=>setTimeout(r,3000));
  const dt=(performance.now()-t0)/1000;
  return {degPerSec:+((HERO.rot-r0)*180/Math.PI/dt).toFixed(2), fps:+(f/dt).toFixed(1)};
})()`;
(async()=>{ const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  for(const f of ['A-base','NEW']){
    const out=[];
    for(const load of ['false','true']){
      const p=await b.newPage({viewport:{width:1200,height:800}});
      await p.goto('file://'+process.cwd()+'/vtest/'+f+'.html');
      await p.waitForTimeout(11000);
      out.push(await p.evaluate(MEASURE(load)));
      await p.close();
    }
    const drift=(out[1].degPerSec/out[0].degPerSec*100).toFixed(0);
    console.log(f.padEnd(8),'light:',JSON.stringify(out[0]),' heavy:',JSON.stringify(out[1]),
                ` speed held: ${drift}%`);
  }
  await b.close(); })();
