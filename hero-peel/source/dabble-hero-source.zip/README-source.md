# Dabble hero — build source

`dabble-hero-peel.html` is a single self-contained file (~2.3 MB): images and logo are
embedded as data URIs, all CSS and JS inline. The only external dependency is the
Google Fonts link for Roboto Mono, so the page needs a network connection for type
(everything else works offline).

That file is **generated**. Do not hand-edit it — edit the pieces below and rebuild.

## Rebuild

```
python3 buildH.py            # must be run from this folder
```

Writes `build4/peel-v2.html`. Copy that to `dabble-hero-peel.html` to ship it.

## Pieces

| file | what it is |
|---|---|
| `tpl2/base.html` | the shared bloom engine — spiral layout, drift loop, `HERO` state object. Used by all eleven prototypes. |
| `tpl2/H-peel.txt` | the Peel layer: sunrise sky, peel mechanics, hover/pick-up, story card, logo. `TITLE::` / `HINT::` header, then `/*=== STYLE ===*/`, `/*=== MARKUP ===*/`, `/*=== SCRIPT ===*/` sections. |
| `tpl2/stories.js` | the twelve case studies, keyed by image id. **Placeholder copy.** |
| `images.json` | twelve optimised images as `[{id,w,h,src}]`, src = base64 JPEG data URI |
| `logo.json` | `{white, black}` — the stacked mark as base64 SVG data URIs, viewBox trimmed to the artwork, background rect stripped |
| `buildH.py` | composes the above into one file |
| `tpl2/A…J-*.txt` | the other ten navigation prototypes, same fragment format |

## Test harnesses (need `npm i playwright`, Chromium at `/opt/pw-browsers/chromium`)

- `final.js` — hover, open, Esc, backdrop close, peel. The smoke test; run after every change.
- `perf.js` — frame times during a peel drag
- `drift5.js` — idle-drift frame times, jitter, p90/p99
- `ratetest.js` — is the drift speed the same under load as at rest

Absolute frame numbers from a headless sandbox are software-rasterised and far worse
than a real machine. Only the ratios between runs mean anything.
