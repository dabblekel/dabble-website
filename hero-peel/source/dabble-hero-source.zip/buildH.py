import json, re, os
imgs=open('images.json').read()
logo=open('logo.json').read()
icon=open('icon.json').read()
base=open('tpl2/base.html').read()
raw=open('tpl2/H-peel.txt').read()
title=re.search(r'^TITLE::(.*)$',raw,re.M).group(1).strip()
hint =re.search(r'^HINT::(.*)$',raw,re.M).group(1).strip()
style=raw.split('/*=== STYLE ===*/')[1].split('/*=== MARKUP ===*/')[0]
markup=raw.split('/*=== MARKUP ===*/')[1].split('/*=== SCRIPT ===*/')[0]
script=raw.split('/*=== SCRIPT ===*/')[1]
page=(base.replace('/*NAV_STYLE*/',style).replace('<!--NAV_MARKUP-->',markup)
          .replace('/*NAV_SCRIPT*/',script).replace('__TITLE__',title).replace('__HINT__',hint))
page=page.replace('<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;800&display=swap" rel="stylesheet">',
 '<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;800&family=Roboto+Mono:wght@300;400;500;700&display=swap" rel="stylesheet">')
assert 'Roboto+Mono' in page and '__LOGO__' in page and '__ICON__' in page
page=page.replace('__STORIES__',open('tpl2/stories.js').read())
page=page.replace('__LOGO__',logo).replace('__ICON__',icon).replace('__IMAGES__',imgs)
os.makedirs('build4',exist_ok=True)
open('build4/peel-v2.html','w').write(page)
print('peel-v2.html', round(len(page)/1048576,2),'MB')
