lift.txt is generated, not hand-written.

  extract-lift.py    pulls the sky CSS and the colour/geometry helpers verbatim out of
                     tpl2/H-peel.txt and writes /tmp/parts.py
  assemble-lift.py   wraps those in the sub-page host (frame-loop shim, drag handling,
                     nav) and writes tpl2/lift.txt

Run both, from the folder holding tpl2/, after retuning the peel in H-peel.txt:

    python3 tools/extract-lift.py && python3 tools/assemble-lift.py

The two sub-page-specific overrides - the ink-coloured corner flap and the inverted
logo flip - live in assemble-lift.py's template, not in H-peel.txt.

Which rules get carried across is the WANT list at the top of extract-lift.py, with
hero-only rules named in SKIP beside it. Neither list maintains itself, so extract-lift
refuses to run if H-peel.txt grows a lift rule that is in neither - put it in WANT to
carry it to sub-pages, or in SKIP to keep it on the hero.
