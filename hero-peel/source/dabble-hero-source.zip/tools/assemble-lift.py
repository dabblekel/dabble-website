import sys; sys.path.insert(0,'/tmp')
from parts import SKY_CSS, HELPERS

TPL = '''/*=== STYLE ===*/
  /* ---- the corner lift, on a sub-page ----
     Same fold, same sunrise, same nav as the hero: the CSS below and the sky maths in the
     script are taken verbatim from H-peel.txt by tools/mklift. What differs is the host.
     The hero drives the peel from its HERO object and fades the bloom out behind the sky;
     a sub-page has no bloom, so it fades its own content on the same curve and runs the
     peel on a small frame-loop shim. Two implementations of one idea: if you retune the
     peel in H-peel.txt, regenerate this. */
{CSS}

  /* ---- what changes because a sub-page is cream, not black ----
     The hero rests on a near-black bloom, so its info mark is the white drawing and its
     wordmark stays white until the paper or the sun reaches it. Here the resting ground
     is cream, so both of those read as invisible-on-invisible. The info mark is swapped
     for the black drawing in the script below, and the wordmark's flip is inverted. */
  /* the page arrives blank: the lift's frame loop fades the content and the mark in */
  #sheet{opacity:0}
  /* The hero's mark is decorative and carries pointer-events:none. Here it is the link
     home, so it has to take a click - and the nav list has to as well, once the page
     underneath it is hidden. */
  .logo{pointer-events:auto;cursor:pointer}

/*=== MARKUP ===*/
  <div class="dawn" id="dawn"></div>
  <div class="glow" id="glow"></div>
  <div class="grain" id="grain"></div>
  <div class="paper" id="paper"></div>
  <div class="under" id="under"><ol id="underList"></ol></div>
  <div class="limbGlow" id="limbGlow"></div>
  <div class="fold" id="fold"></div>
  <div class="limb" id="limb"></div>
  <div class="dog" id="dog" title="lift"></div>
  <a class="logo" id="logo" href="/"></a>
/*=== SCRIPT ===*/
(function(){
  const PAGES = __PAGES__, HERE = __HERE__, LOGO = __LOGO__, ICON = __ICON__;
  const $ = id => document.getElementById(id);
  const dawn=$('dawn'), glow=$('glow'), grain=$('grain'), paper=$('paper'),
        under=$('under'), underList=$('underList'), limbGlow=$('limbGlow'),
        fold=$('fold'), limb=$('limb'), dog=$('dog'), logo=$('logo'), sheet=$('sheet');
  [dawn,glow,grain,paper,under,limbGlow,fold,limb,dog,logo]
    .forEach(el=>document.body.appendChild(el));

  dog.innerHTML = '<img src="'+ICON.black+'" alt="">';
  logo.innerHTML = '<img class="spacer" src="'+LOGO.white+'" alt="Dabble">'
                 + '<img class="w" src="'+LOGO.white+'" alt="">'
                 + '<img class="b" src="'+LOGO.black+'" alt="">';
  const logoW=logo.querySelector('.w'), logoB=logo.querySelector('.b');

  /* The hero supplies dt, ease and a frame list from its HERO object. There is no bloom
     here, so stand those three up alone - same shape, same time-based easing, so the peel
     behaves identically at any refresh rate. */
  const LIFT={dt:1,frame:[],ease:k=>1-Math.pow(1-k,LIFT.dt)};
  let _last=performance.now();
  function tick(now){
    const t=now||performance.now();
    LIFT.dt=Math.min(Math.max(t-_last,4),50)/16.667; _last=t;
    LIFT.frame.forEach(f=>f());
    requestAnimationFrame(tick);
  }

  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const SQ2=Math.SQRT2;
  let SPAN=0, SKYH=0, SUNR=0, WASHR=0, LIMBL=0, GLOWL=0;

{JS}

  let logoBox=null;
  const measureLogo=()=>{ logoBox=logo.getBoundingClientRect() };
  addEventListener('resize',()=>{ measureLogo(); buildSky() });
  setTimeout(()=>{ measureLogo(); buildSky() },0);

  const items=PAGES.map(p=>{
    const li=document.createElement('li');
    li.innerHTML='<span>'+p.label+'</span>';
    li.addEventListener('click',e=>{
      e.stopPropagation();
      li.querySelector('span').animate(
        [{transform:'translateX(-14px)'},{transform:'translateX(-40px)',opacity:.15},
         {transform:'translateX(-14px)',opacity:1}],
        {duration:620,easing:'cubic-bezier(.2,.8,.2,1)'});
      if(p.label===HERE){ open=false; want=0; return }   // already here: lay it back down
      if(p.url) leaveTo(p.url);
    });
    underList.appendChild(li); return li;
  });

  const MAXD=()=>innerWidth+innerHeight;
  /* rest the peel short of the mark, exactly as the hero does */
  const OPEN=()=>{
    const r=logoBox||logo.getBoundingClientRect();
    /* Tall/portrait screens: peel a little past the brand mark so the crease clears it
       and the whole logo sits cleanly on the cream, matching the hero. */
    if(innerHeight > innerWidth){
      const cMax=(innerWidth-r.left)+(innerHeight-r.top);
      const pad=Math.max(58, innerHeight*0.045);
      return clamp(Math.max(MAXD()*0.32, cMax+pad), 0, MAXD()*0.9);
    }
    const clear=r.right+r.bottom+Math.max(90,innerWidth*0.06);
    return Math.max(MAXD()*0.32, MAXD()-clear);
  };
  let d=0, want=0, dragging=false, moved=false, open=false, sx=0, sy=0;
  let lastPT='mouse';

  /* Leaving: carry the peel all the way past the far corner so the paper covers the whole
     window - cream ground, black mark - and only then follow the link. The next page opens
     on the same cream ground with the same black mark, so the two documents meet on an
     identical frame and the seam does not show. */
  let leaving=null, leaveAt=0, went=false;
  function leaveTo(url){
    if(leaving) return;
    leaving=url; leaveAt=performance.now(); open=true; want=MAXD();
  }

  /* Arriving: the content and the flap ease in over the cream. */
  const ENTRY_DELAY=90, ENTRY_MS=620, T0=performance.now();
  let entry=0;
  const onPaper=(x,y)=>((innerWidth-x)+(innerHeight-y)) < d;
  const nearCorner=(x,y)=>((innerWidth-x)+(innerHeight-y))<340;
  /* Opening is a tap/click of the info mark alone - the generous 340 corner band no longer
     opens the menu, so a tap meant for content near the corner is never swallowed. */
  const onDog=(x,y)=>{ const r=dog.getBoundingClientRect(), pad=12;
    return x>=r.left-pad && x<=r.right+pad && y>=r.top-pad && y<=r.bottom+pad; };

  addEventListener('pointerdown',e=>{
    if(leaving) return;
    lastPT=e.pointerType;
    /* Anything the page itself owns takes the press: the mark, the nav, an open profile,
       and the headshots - on a narrow screen a headshot can sit inside the corner band,
       and tapping it must open that person, not start a peel. */
    if(e.target.closest('#logo,#underList,.ovl,.face')) return;
    sx=e.clientX; sy=e.clientY; moved=false;
    /* Drag only ever adjusts an already-open menu; opening is a tap of the info mark.
       On a sub-page the drag is mouse-only: a touch-drag would fight the page's own
       scroll behind the peel, so on touch the menu is tap-to-open / tap-off-to-close
       with no drag. (The hero has no scroll behind it, so it keeps the touch-drag.)
       A sub-page body is not user-select:none, so cancel only presses that start a drag. */
    if(open && e.pointerType!=='touch'){ e.preventDefault();
      dragging=true; document.body.style.cursor='grabbing' }
  });
  addEventListener('pointermove',e=>{
    if(Math.hypot(e.clientX-sx,e.clientY-sy)>(lastPT==='touch'?10:6)) moved=true;
    if(!dragging) return;
    if(moved) want=clamp((innerWidth-e.clientX)+(innerHeight-e.clientY),0,MAXD());
  });
  addEventListener('pointerup',e=>{
    if(leaving) return;
    /* Opening is a tap/click of the info mark alone; dragging (mouse only) adjusts an
       already-open menu and can drag it closed. A corner swipe never opens it. */
    const wasDrag = dragging && moved;
    dragging=false; document.body.style.cursor='';
    if(wasDrag){ open = want > OPEN()*0.42; want = open? OPEN() : 0; return; }
    if(moved) return;                                    // a scroll/slide, not a tap
    if(open){ if(!onPaper(e.clientX,e.clientY)){ open=false; want=0 } return; }  // tap off the open paper → close
    if(onDog(e.clientX,e.clientY)){ open=true; want=OPEN(); }                    // only the info mark opens
  });
  addEventListener('keydown',e=>{ if(e.key==='Escape' && open){ open=false; want=0 } });

  let warm=false, grainOn=false, lastSun=-1, foldOn=false, sunCx=0, sunCy=0;

  LIFT.frame.push(()=>{
    if(dragging) d=want;
    else { d+=(want-d)*LIFT.ease(0.1); if(Math.abs(want-d)<0.4) d=want }

    const _now=performance.now();
    entry=clamp((_now-T0-ENTRY_DELAY)/ENTRY_MS,0,1);
    const ein=entry*entry*(3-2*entry);          // smoothstep, so the arrival is not a step
    /* `leaving` is never cleared, and the frame is not cut short. The browser keeps
       painting this document until the new one commits, so clearing it would let lv fall
       back to 0 and flash the links bright again on the last frames before the change. */
    if(leaving && !went && (d>MAXD()*0.985 || _now-leaveAt>1600)){
      went=true; location.href=leaving;
    }
    const dp=-d/SQ2, off=-SPAN/2;
    paper.style.transform=`rotate(-45deg) translate(${off}px,${dp.toFixed(1)}px)`;
    const T=innerWidth+innerHeight;
    const q=clamp(d/OPEN(),0,1.6);

    /* The page's content fades out entirely behind the sky, on the same 0.95 -> 0.75
       window the hero uses for its bloom: finished while the sky is still near-solid, so
       nothing is ever seen half-drawn through the night side. */
    const fadeOut=clamp((0.95-q)/0.20,0,1);
    const shown=fadeOut*ein;
    if(sheet){ sheet.style.opacity=shown;
               sheet.style.visibility=shown>0.001?'':'hidden' }

    if((d>2)!==grainOn){ grainOn=d>2; grain.style.opacity=grainOn?0.06:0 }

    const sun=clamp((q-0.42)/0.5,0,1);
    const sq=Math.round(sun*100)/100;
    if(sq!==lastSun){
      lastSun=sq;
      dawn.style.opacity=sq; glow.style.opacity=sq;
      limb.style.opacity=sq; limbGlow.style.opacity=sq;
    }
    if((sun>0)!==warm){ warm=sun>0;
      fold.style.background = warm
        ? 'linear-gradient(90deg,rgba(255,228,190,0) 34%,rgba(255,228,190,.30) 50%,rgba(255,214,160,0) 68%)'
        : 'linear-gradient(90deg,rgba(255,255,255,0) 30%,rgba(255,255,255,.7) 50%,rgba(255,255,255,0) 72%)';
    }
    if(sq>0){
      dawn.style.transform=`rotate(-45deg) translate(${off}px,${(dp-SKYH).toFixed(1)}px)`;
      const S=T-d;
      const x1=Math.min(S,innerWidth),  y1=S-x1;
      const y2=Math.min(S,innerHeight), x2=S-y2;
      const hx=x2+(x1-x2)*0.29, hy=y2+(y1-y2)*0.29;
      const k=SUNR*0.28;                          // buried under the horizon
      sunCx=hx+k; sunCy=hy+k;
      glow.style.transform=`translate(${sunCx.toFixed(1)}px,${sunCy.toFixed(1)}px) translate(-50%,-50%)`;
      limb.style.transform=`translate(${hx.toFixed(1)}px,${hy.toFixed(1)}px) rotate(-45deg) translate(-50%,-2px)`;
      limbGlow.style.transform=`translate(${hx.toFixed(1)}px,${hy.toFixed(1)}px) rotate(-45deg) translate(-50%,-25px)`;
    }

    if((d>6)!==foldOn){ foldOn=d>6; fold.style.opacity=foldOn?1:0 }
    dog.style.opacity = clamp(1-q*8,0,1)*ein;

    /* On the way out the links fade with the last of the fold, so the final frame before
       the link is followed is bare cream and a black mark - the frame the next page opens
       on. Leave them lit and they pop away at the seam. */
    const lv = leaving ? clamp((d-OPEN())/Math.max(1,MAXD()-OPEN()),0,1) : 0;
    items.forEach((li,i)=>{
      const o=clamp((q-(0.18+i*0.09))/0.28,0,1)*(1-lv);
      li.style.opacity=o;
      li.style.transform=`translateX(${(1-o)*30}px)`;
    });
    under.classList.toggle('live', q>0.5);

    /* the mark flips white -> black if the paper reaches it, or if the sky behind it gets
       bright enough that white would stop reading */
    const r=logoBox||logo.getBoundingClientRect();
    const lx=r.left+r.width*0.5, ly=r.top+r.height*0.5;
    const c=(innerWidth-lx)+(innerHeight-ly);
    const onPaperNow=clamp((d-(c-110))/200,0,1);
    const lit=sun>0? clamp((1-Math.hypot(lx-sunCx,ly-sunCy)/SUNR-0.60)/0.10,0,1)*sun : 0;
    /* Inverted from the hero. There the mark starts white on a black bloom and goes black
       when the paper or the sun arrives. Here it starts black on a cream page and goes
       white only once the night sky is behind it - minus the sun's wash, and minus the
       paper if the fold ever reached it. */
    const dark=clamp(sq-lit-onPaperNow,0,1);
    logoW.style.opacity=dark; logoB.style.opacity=1-dark;
  });

  tick();
})();
'''
open('tpl2/lift.txt','w',encoding='utf-8').write(
    TPL.replace('{CSS}', SKY_CSS).replace('{JS}', HELPERS))
import os; print('wrote tpl2/lift.txt', os.path.getsize('tpl2/lift.txt'), 'bytes')
