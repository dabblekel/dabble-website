import re, sys, os
s = open('tpl2/H-peel.txt', encoding='utf-8').read()
STYLE  = s.split('/*=== STYLE ===*/')[1].split('/*=== MARKUP ===*/')[0]
SCRIPT = s.split('/*=== SCRIPT ===*/')[1]

def css(sel):
    m = re.search(r'(?m)^\s*' + re.escape(sel) + r'\s*\{', STYLE)
    if not m: raise SystemExit('css not found: ' + sel)
    i = STYLE.index('{', m.start()); depth = 0
    for j in range(i, len(STYLE)):
        if STYLE[j] == '{': depth += 1
        elif STYLE[j] == '}':
            depth -= 1
            if depth == 0: return STYLE[m.start():j+1].strip('\n')
    raise SystemExit('unbalanced: ' + sel)

def js(start, kind='brace'):
    i = SCRIPT.index(start)
    if kind == 'stmt':
        depth = 0
        for j in range(i, len(SCRIPT)):
            c = SCRIPT[j]
            if c in '([{': depth += 1
            elif c in ')]}': depth -= 1
            elif c == ';' and depth == 0: return SCRIPT[i:j+1]
    depth = 0; seen = False
    for j in range(i, len(SCRIPT)):
        if SCRIPT[j] == '{': depth += 1; seen = True
        elif SCRIPT[j] == '}':
            depth -= 1
            if seen and depth == 0:
                k = SCRIPT.find('\n', j)
                return SCRIPT[i:k if k > 0 else j+1]
    raise SystemExit('unbalanced js: ' + start)

WANT = ['.dawn','.glow','.grain','.paper','.under','.under.live ol','.under ol','.under li',
        '.under li span','.under li:hover span','.fold','.limbGlow','.limb',
        '.dog','.dog img','.logo','.logo img','.logo img.b','.logo .spacer']

# Hero-only, and deliberately not carried across.
SKIP = ['.under .credit']   # the credit line belongs to the story card under the cursor

# This list is hand-maintained, and a rule added to H-peel.txt does not find its own way
# into it: `.under.live ol` was missed once, which left the sub-page menu visible but
# unclickable. So check the two are still in step and say so loudly if they are not.
def selectors():
    out = []
    for m in re.finditer(r'(?m)^  (\.[^{\n]*?)\s*\{', STYLE):
        out.append(m.group(1).strip())
    return out

known = set(WANT) | set(SKIP)
strays = [s for s in selectors()
          if s.split()[0].split(':')[0].split('.live')[0] in
             {'.dawn','.glow','.grain','.paper','.under','.fold','.limbGlow','.limb','.dog','.logo'}
          and s not in known]
if strays:
    raise SystemExit('H-peel.txt has lift rules this script does not know about:\n  '
                     + '\n  '.join(strays)
                     + '\nAdd each to WANT (carry it to sub-pages) or SKIP (hero only).')

SKY_CSS = "\n".join(css(x) for x in WANT)
HELPERS = "\n".join([js('const ramp'), js('const taper=('), js('const taperMask'),
                     js('const stops','stmt'), js('const SKY','stmt'),
                     js('const SUN','stmt'), js('const WASH','stmt'),
                     js('function buildSky')])
open('/tmp/parts.py','w',encoding='utf-8').write(
    'SKY_CSS = %r\nHELPERS = %r\n' % (SKY_CSS, HELPERS))
print('extracted %d bytes of css, %d of js' % (len(SKY_CSS), len(HELPERS)))
