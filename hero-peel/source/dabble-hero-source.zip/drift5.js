const { chromium } = require('playwright');
const RUN = `(()=>{ window.__ft=[]; let l=performance.now();
  (function loop(){ const n=performance.now(); window.__ft.push(n-l); l=n; requestAnimationFrame(loop) })(); })()`;
const STAT = `(()=>{ const raw=window.__ft.slice(5), a=raw.slice().sort((x,y)=>x-y);
  const q=t=>+a[Math.floor(a.length*t)].toFixed(1);
  let j=0; for(let i=1;i<raw.length;i++) j+=Math.abs(raw[i]-raw[i-1]);
  return {med:q(.5), p90:q(.9), p99:q(.99), jit:+(j/(raw.length-1)).toFixed(1)}; })()`;
const CASES=[['OLD build','A-base'],['NEW build','NEW']];
(async()=>{ const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  for(const [name,f] of CASES){ const runs=[];
    for(let r=0;r<3;r++){ const p=await b.newPage({viewport:{width:1600,height:1000}});
      await p.goto('file://'+process.cwd()+'/vtest/'+f+'.html');
      await p.waitForTimeout(11500); await p.evaluate(RUN); await p.waitForTimeout(4000);
      runs.push(await p.evaluate(STAT)); await p.close(); }
    const m=k=>runs.map(r=>r[k]).sort((x,y)=>x-y)[1];
    console.log(name.padEnd(11), JSON.stringify({med:m('med'),p90:m('p90'),p99:m('p99'),jit:m('jit')})); }
  await b.close(); })();
